drop table [PERSIMUNE_Playground].[dbo].[QA.TEMP1]
  Select * 
  into [PERSIMUNE_Playground].[dbo].[QA.TEMP1]
  FROM [PERSIMUNE_DATA].[dbo].[tbl_QA_Biochemistry]
  where C_AnalysisGroup in ('haem', 'leuk', 'bas', 'eos', 'lym', 'neu', 'mon', 'thr', 'alb', 'alp', 'alt', 'ldh', 'bun', 'gluc', 'bil', 'cre', 'inr', 'na+', 'k+', 'crp')
  and [CreatedTime] < '2016-10-01 03:13:04.7530000' 

  -- Check to see how many samples have non-numeric result values by dividing the bottom number with the top number
  SELECT count(1) as antal
  FROM [PERSIMUNE_Playground].[dbo].[QA.TEMP1]
  where C_Doublet = 0
	and Rec_deleted = 0
  
  SELECT count(1) as antal
  FROM [PERSIMUNE_Playground].[dbo].[QA.TEMP1]
  where ISNUMERIC(resultvalue)=0
	and C_Doublet = 0
	and Rec_deleted = 0

    -- Number of tests performed for per year 

  select year(c_samplingdatetime) as aar, count(1) as antal
  from [PERSIMUNE_Playground].[dbo].[QA.TEMP1]
  where Rec_deleted = 0
  and c_doublet = 0
  group by year(c_samplingdatetime)
  order by aar
 
  -- Number of tests performed for each patient the first year after entry in the PERSIMUNE datawarehouse 
   
  select left(persimuneentrydate,4) as �r, count(distinct(cprnr)) as antalpatienter, count(1) as antalpr�ver, count(1)/count(distinct(cprnr)) as antalpr�verperpatient from
(
select c_samplingdatetime, A.CPRNR, ResultValue, PersimuneEntryDate from
	[PERSIMUNE_SA].[dbo].[tbl_STAT_PersimunePatients_Groups] A left join [PERSIMUNE_Playground].[dbo].[QA.TEMP1] B
	on a.CPRNR = b.CPRNR
	where datediff(day,persimuneentrydate,c_Samplingdatetime) >= 0
	and datediff(day,persimuneentrydate,c_Samplingdatetime) <= 365
	and Rec_deleted = 0
	and C_Doublet = 0
	and patientgroupcode in ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I') 
) A
group by left(persimuneentrydate,4)
order by �r
