SELECT TOP 1000 [AnalysisGroup]
      ,[AnalysisCode]
      ,[AnalysisCodeResponsible]
      ,[AnalysisName]
      ,[CreatedDatetime]
      ,[ID]
  FROM [PERSIMUNE_Meta].[dbo].[tbl_TYPE_AnalysisGroups]
  where (AnalysisName like '%cholesterol%'
or AnalysisName like '%kolesterol%') 
and AnalysisName not like '%HDL%'
and AnalysisName not like '%LDL%'
and AnalysisName not like '%DNA%'
and AnalysisName not like '%asc%'
and AnalysisName not like '%refleks%'
and AnalysisName not like '%plv%'
and AnalysisName not like '%dehydrochole%'
and AnalysisCode not like '%EQA%'
and AnalysisCode !='NPU18413'


