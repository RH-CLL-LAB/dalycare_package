SELECT TOP 1000 [AnalysisGroup]
      ,[AnalysisCode]
      ,[AnalysisName]
      ,[AnalysisCodeResponsible]
  FROM [PERSIMUNE_Meta].[dbo].[tbl_TYPE_AnalysisGroups]
 
  where 
  (AnalysisName like '%lupus%'
  or analysisname like '%antikoag%')
  and AnalysisName not like '%kutan%'
  and AnalysisName not like '%neuron%'
  and AnalysisName not like '%Indikation: APA/Lupus kontrol%'
  and AnalysisName not like '%P-Ekstra LUPUS til Signe%'
and AnalysisName not like '%S�raftale Antikoagulationsprojekt (2031)%'
and AnalysisName not like '%P-Screening for cirkulerende antikoagulans%'
and AnalysisName not like '%Lupus la%'
order by AnalysisCode
