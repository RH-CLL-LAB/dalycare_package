/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 1000 [AnalysisGroup]
      ,[AnalysisCode]
      ,[AnalysisCodeResponsible]
      ,[AnalysisName]
      ,[CreatedDatetime]
      ,[ID]
  FROM [PERSIMUNE_Meta].[dbo].[tbl_TYPE_AnalysisGroups]
  where (AnalysisName like '%LDL%'
  or AnalysisName like '%Low density lipo%'
  or analysisname like '%beta lipo%')
  and analysisname not like '%DNA%'
  and analysisname not like '%frakt%'
  and analysisname not like '%VLDL%'
  