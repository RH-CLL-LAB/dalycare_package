
SELECT TOP 1000 [AnalysisGroup]
      ,[AnalysisCode]
      ,[AnalysisCodeResponsible]
      ,[AnalysisName]
      ,[CreatedDatetime]
      ,[ID]
  FROM [PERSIMUNE_Meta].[dbo].[tbl_TYPE_AnalysisGroups]
  where (AnalysisName like'%HDL%'
  or analysisname like '%high density lipo%')
  and AnalysisName not like '%ratio%'
  and AnalysisName not like '%plv%'
  and AnalysisName not like '%frakt%'
  