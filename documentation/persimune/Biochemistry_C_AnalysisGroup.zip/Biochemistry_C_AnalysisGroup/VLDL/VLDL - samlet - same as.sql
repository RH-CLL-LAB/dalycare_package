SELECT TOP 1000 [AnalysisGroup]
      ,[AnalysisCode]
      ,[AnalysisCodeResponsible]
      ,[AnalysisName]
      ,[CreatedDatetime]
      ,[ID]
  FROM [PERSIMUNE_Meta].[dbo].[tbl_TYPE_AnalysisGroups]
  where (analysisname like '%VLDL%' 
  or AnalysisName like '%very low density lipo%')
  and AnalysisName not like '%frakt%'
  