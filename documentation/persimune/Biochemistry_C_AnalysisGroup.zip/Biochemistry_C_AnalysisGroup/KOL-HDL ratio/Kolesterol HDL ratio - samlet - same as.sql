SELECT TOP 1000 [AnalysisGroup]
      ,[AnalysisCode]
      ,[AnalysisCodeResponsible]
      ,[AnalysisName]
      ,[CreatedDatetime]
      ,[ID]
  FROM [PERSIMUNE_Meta].[dbo].[tbl_TYPE_AnalysisGroups]
  
  where (AnalysisName like '%cholesterol%'
  or AnalysisName like '%kolesterol%')
  and AnalysisName like '%ratio%'
 
