
--NB, all analyses should be expanded if errors or inconsistencies are found!
  
  -- Here we create a temporary table in the playground. Remember to delete it with the last coding after you have cleaned-up (see bottom of syntax).

  -- If the table is not deleted before you start, use the below coding to remove it

   drop table #t01

  -- the last tests are across tables and you need to manually write the analysisgroup in question

  -- Let c_analysigroup be the one you are interested in and the [CreatedTime] be the saturday before you are cleaning (because QA steps are applied on sundays).

  Select * 
  into #t01
  FROM [PERSIMUNE_DATA].[dbo].[tbl_QA_Biochemistry]
  where C_AnalysisGroup = 'nk'
  --and Rec_deleted = 0
 -- and [CreatedTime] < '2018-06-26 00:13:04.7530000' 

-- This is just a list of the analyses codes found in the "same as" step of the governance model
select distinct 
AnalysisCode, count(1) as antal
FROM #t01
group by AnalysisCode
order by antal desc


-- All names should be something correct pertaining to the analysisgroup
select distinct 
AnalysisName, count(1) as antal
FROM #t01
group by AnalysisName

select distinct 
analysiscode, AnalysisName, count(1) as antal
FROM #t01
group by analysiscode, AnalysisName
order by analysiscode, AnalysisName

-- All names should be something correct pertaining to the analysisgroup
select distinct 
AnalysisMnemonic, count(1) as antal
FROM #t01
group by AnalysisMnemonic

-- If there is a resultunit, this should be correctly displayed in c_displayunit, otherwise it needs to be updated 
-- IE there must not be a null value in c_displayunit if there is something written in the resultunit
select distinct 
C_DisplayUnit, ResultUnit, count(1) as antal
FROM #t01
where c_doublet = 0
and Rec_deleted = 0
and c_missingresultvalue = 0
group by C_DisplayUnit, ResultUnit

-- If there was an error in displayunit, we need to see what was wrong:

SELECT TOP 100 *
  FROM #t01
  where C_DisplayUnit is null
  and c_doublet = 0
and Rec_deleted = 0
and C_MissingResultValue = 0

-- Check if all referenceintervals makes clinical sense. The ones with c_ in front is the calculated numeric value. The different intervals are (most often) due to sex and age of the patient.

select distinct 
ReferenceIntervalLowerLimit, C_ReferenceIntervalLowerLimitNumeric, ReferenceIntervalUpperLimit, C_ReferenceIntervalUpperLimitNumeric, count(1) as antal
FROM #t01
where c_doublet = 0
and Rec_deleted = 0
and C_MissingResultValue = 0
group by ReferenceIntervalLowerLimit, C_ReferenceIntervalLowerLimitNumeric, ReferenceIntervalUpperLimit, C_ReferenceIntervalUpperLimitNumeric
order by ReferenceIntervalLowerLimit asc

--Both MedCom and Labka should be present as datasource
select distinct 
DataSource, count(1) as antal
FROM #t01
group by datasource

-- Check which operators are applied to the analysis group. Operators are important because if an analysis have results between 0 and 50 and 
-- some of the results are only marked as >20 then you will have trouble in the mathematical/statistical analysis of data if you are not aware of this
-- the operator ' denotes a text string in the result value

select distinct 
C_Operator, count(1) as antal
FROM #t01
where c_doublet = 0
and Rec_deleted = 0
and C_MissingResultValue = 0
group by C_Operator

-- At which cutoffs do the operator < or <= apply? This should be included in the QA rapport
SELECT distinct c_resultvaluenumeric as new_resultvalue, ResultValue as old_resultvalue, Operator, count(1) as antal
  FROM #t01
  where  Operator like '%<%'
and c_doublet = 0
and Rec_deleted = 0
and c_missingresultvalue = 0
group by C_ResultValueNumeric, ResultValue, Operator
order by C_ResultValueNumeric

-- At which cutoffs do the operator > or >= apply? This should be included in the QA rapport
SELECT distinct c_resultvaluenumeric as new_resultvalue, ResultValue as old_resultvalue, operator, count(1) as antal
  FROM #t01
  where  Operator like '%>%'
and c_doublet = 0
and Rec_deleted = 0
and c_missingresultvalue = 0
group by C_ResultValueNumeric, ResultValue, Operator
order by C_ResultValueNumeric

-- check which resultvalues apply to samples with an operator. NB, this analysis should often be investigated thoroughly.
SELECT TOP 100 *
  FROM #t01
  where  Operator is not null
and Operator != '='
and c_doublet = 0
and Rec_deleted = 0
and C_MissingResultValue = 0

-- Check if important knowledge is hidden in the comments section
select  
ResultComment, ResultTextValue, count(1) as antal
FROM #t01
where c_doublet = 0
and Rec_deleted = 0
and c_missingresultvalue = 0
group by ResultComment, ResultTextValue
order by antal desc

  -- See if the highest numeric values are relevant
  SELECT TOP 100 *
  FROM #t01
  where C_ResultValueNumeric is not null
  and c_doublet = 0
and Rec_deleted = 0
and C_MissingResultValue = 0
  order by C_ResultValueNumeric desc

  -- Check if the lowest numeric values are relevant

  SELECT TOP 100 *
  FROM #t01
  where C_ResultValueNumeric is not null
  and c_doublet = 0
and Rec_deleted = 0
and C_MissingResultValue = 0
  order by C_ResultValueNumeric asc

  -- Check to see the proportion of samples that have non-numeric result values by dividing the bottom number with the top number
  SELECT count(1) as antal
  FROM #t01
  where C_Doublet = 0
	and Rec_deleted = 0
	
  
  SELECT count(1) as antal
  FROM #t01
  where ISNUMERIC(resultvalue)=0
	and C_Doublet = 0
	and Rec_deleted = 0
 
  -- check the most common non-numeric answers, these need to be grouped in rec_deleted (e.g. cancelled tests) and missing values (e.g. hemolysis or note answer). 

select c_resultvaluenumeric, resultvalue, count(1) as antal
FROM #t01
where ISNUMERIC(resultvalue)=0
  and Rec_deleted = 0
  and C_Doublet = 0
  and C_MissingResultValue = 0
  group by c_resultvaluenumeric, ResultValue
  order by antal desc

  select C_CategoricalResult, resultvalue, count(1) as antal
FROM #t01
where ISNUMERIC(resultvalue)=0
  and Rec_deleted = 0
  and C_Doublet = 0
  and C_MissingResultValue = 0
  group by C_CategoricalResult, ResultValue
  order by antal desc

    select C_CategoricalResult, resultvalue, count(1) as antal
FROM #t01
where ISNUMERIC(resultvalue)=1
  and Rec_deleted = 0
  and C_Doublet = 0
  and C_MissingResultValue = 0
  group by C_CategoricalResult, ResultValue
  order by antal desc

  select count(1) as antal
FROM #t01
where Rec_deleted = 0
  and C_Doublet = 0
  and C_MissingResultValue = 0
 and C_CategoricalResult is null

  select distinct resultcomment, count(1) as antal
   FROM #t01
  where Rec_deleted = 0
  --and DataSource = 'labka'
  group by ResultComment
  order by antal desc

  
  -- Check those without a calculated resultvalue 

  SELECT ResultValue, count(1) as antal
  FROM #t01
  where C_ResultValueNumeric is null
  and Rec_deleted = 0
  and C_Doublet = 0
and C_MissingResultValue = 0
  group by resultvalue
  order by antal desc

  -- Frequency per year for the variable

  select year(c_samplingdatetime) as aar, count(1) as antal
  from #t01
  where Rec_deleted = 0
  and c_doublet = 0
  group by year(c_samplingdatetime)
  order by aar
  
  -- Number of tests performed for each patient the first year after entry in the PERSIMUNE datawarehouse 

  select left(persimuneentrydate,4) as �r, count(distinct(cprnr)) as antalpatienter, count(1) as antalpr�ver, count(1)/count(distinct(cprnr)) as antalpr�verperpatient from
(
select c_samplingdatetime, A.CPRNR, ResultValue, PersimuneEntryDate from
	[PERSIMUNE_SA].[dbo].[tbl_STAT_PersimunePatients_Groups] A left join #t01 B
	on a.CPRNR = b.CPRNR
	where datediff(day,persimuneentrydate,c_Samplingdatetime) >= 0
	and datediff(day,persimuneentrydate,c_Samplingdatetime) <= 365
	and Rec_deleted = 0
	and C_Doublet = 0
	and patientgroupcode in ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I') 
) A
group by left(persimuneentrydate,4)
order by �r

-- Average values since 2009

SELECT 
dateadd(month, datediff(month, 0, convert(date,c_samplingdatetime,112)), 0) as yrmo,
count(*) as antal, 
AVG
(c_resultvaluenumeric) as mean
  FROM #t01
  where SamplingDateTime >= '2009-01-01 00:00:00.000'
  and C_Doublet = 0
and Rec_deleted = 0
and C_ResultValueNumeric is not null
  group by dateadd(month, datediff(month, 0, convert(date,c_samplingdatetime,112)), 0)
  order by yrmo

-- Median values since 2009

select yrmo, count(1) as antal, median from
(
select dateadd(month, datediff(month, 0, samplingdatetime), 0) as yrmo, 
	percentile_cont(0.5) within group (order by c_resultvaluenumeric) over (partition by dateadd(month, datediff(month, 0, samplingdatetime), 0)) as median
FROM #t01
where year(C_SamplingDatetime) > 2008
--and year(c_samplingdatetime) < 2017
and C_Doublet = 0
and Rec_deleted = 0
and C_ResultValueNumeric is not null
) A
group by yrmo, median
order by yrmo

  --drop table #t01
