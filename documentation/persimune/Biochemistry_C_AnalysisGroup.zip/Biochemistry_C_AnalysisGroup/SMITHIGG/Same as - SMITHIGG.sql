SELECT TOP 1000 [AnalysisGroup]
      ,[AnalysisCode]
      ,[AnalysisName]
      ,[AnalysisCodeResponsible]
  FROM [PERSIMUNE_Meta].[dbo].[tbl_TYPE_AnalysisGroups]
 
  where 
  AnalysisName like '%SMITH%'