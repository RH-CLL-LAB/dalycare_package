SELECT TOP 1000 [AnalysisGroup]
      ,[AnalysisCode]
      ,[AnalysisCodeResponsible]
      ,[AnalysisName]
      ,[CreatedDatetime]
      ,[ID]
  FROM [PERSIMUNE_Meta].[dbo].[tbl_TYPE_AnalysisGroups]
  where (analysisname like '%triglycerid%'
  or AnalysisName like '%trig%'
  or analysisname like '%tgly%')
  and analysisName not like '%dr�nv%'
  and AnalysisName not like '%frakt%'
  and AnalysisName not like '%asc%'
  and AnalysisName not like '%DNA%' 
  and AnalysisName not like '%plv%'
  and AnalysisName not like '%lamotrigin%'
  and AnalysisName not like '%syst%'
  and AnalysisCode !='NPU18413'
